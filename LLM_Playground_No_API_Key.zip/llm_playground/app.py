import requests
import streamlit as st

st.set_page_config(page_title="LLM Playground", page_icon="🧪", layout="wide")

st.markdown("""
<style>
.stApp {background: #0b1020;}
.block-container {max-width: 1400px; padding-top: 1.8rem;}
.hero {padding: 1.4rem 1.6rem; border: 1px solid #293451; border-radius: 18px;
       background: linear-gradient(120deg, #17213b, #111827); margin-bottom: 1rem;}
.hero h1 {margin: 0; color: #f8fafc;}
.hero p {color: #cbd5e1; margin: .4rem 0 0;}
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="hero">
  <h1>🧪 LLM Playground</h1>
  <p>Test prompts, compare local language models, and experiment with temperature and output-token limits. No API key required.</p>
</div>
""", unsafe_allow_html=True)

OLLAMA_URL_DEFAULT = "http://localhost:11434"

USE_CASES = {
    "Custom prompt": {
        "system": "You are a helpful, accurate assistant. Follow the user's instructions.",
        "prompt": "Explain how large language models work in simple terms."
    },
    "1. Text summarizer": {
        "system": "You are an expert editor. Summarize clearly and preserve important facts.",
        "prompt": "Summarize this text in five concise bullet points:\n\nPaste your text here."
    },
    "2. Professional email writer": {
        "system": "You are a professional communication assistant. Write concise, polite emails.",
        "prompt": "Write a professional email requesting an update on my job application. Keep it under 120 words."
    },
    "3. Code explainer": {
        "system": "You are a patient senior software engineer. Explain code accurately for a beginner.",
        "prompt": "Explain this Python code line by line, then give its time complexity:\n\nfor i in range(3):\n    print(i * i)"
    },
    "4. Sentiment analyzer": {
        "system": "You are a sentiment-analysis assistant. Return sentiment, evidence, and a confidence estimate. Do not overstate certainty.",
        "prompt": "Analyze the sentiment of this customer review. Return sentiment, key phrases, and a one-sentence explanation.\n\nReview: The delivery was quick, but the product stopped working after two days."
    },
    "5. Interview coach": {
        "system": "You are an experienced interviewer and career coach. Give practical, structured feedback.",
        "prompt": "Help me answer this interview question using the STAR method: Tell me about a time you solved a difficult problem."
    },
}

def get_models(base_url):
    response = requests.get(f"{base_url.rstrip('/')}/api/tags", timeout=5)
    response.raise_for_status()
    data = response.json()
    return [item["name"] for item in data.get("models", [])]

def run_model(base_url, model, system_prompt, user_prompt, temperature, max_tokens):
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        "stream": False,
        "options": {
            "temperature": temperature,
            "num_predict": max_tokens,
        },
    }
    response = requests.post(
        f"{base_url.rstrip('/')}/api/chat",
        json=payload,
        timeout=300,
    )
    response.raise_for_status()
    data = response.json()
    return {
        "text": data.get("message", {}).get("content", ""),
        "prompt_tokens": data.get("prompt_eval_count", 0),
        "completion_tokens": data.get("eval_count", 0),
        "total_tokens": data.get("prompt_eval_count", 0) + data.get("eval_count", 0),
        "duration": data.get("total_duration", 0) / 1_000_000_000,
        "finish_reason": data.get("done_reason", "done"),
    }

with st.sidebar:
    st.header("⚙️ Playground settings")
    ollama_url = st.text_input("Ollama server URL", value=OLLAMA_URL_DEFAULT,
                               help="Default local Ollama address. For a remote server, enter its reachable URL.")
    st.caption("This project uses Ollama's local HTTP API. No OpenAI API key is needed.")
    if st.button("↻ Refresh model list", use_container_width=True):
        st.session_state.pop("available_models", None)

    try:
        if "available_models" not in st.session_state:
            st.session_state["available_models"] = get_models(ollama_url)
        available_models = st.session_state["available_models"]
    except requests.RequestException:
        available_models = []
        st.session_state["available_models"] = []

    if available_models:
        model_a = st.selectbox("Model A", available_models, index=0)
        model_b = st.selectbox("Model B (comparison)", available_models,
                               index=min(1, len(available_models)-1))
    else:
        model_a = st.text_input("Model A", value="llama3.2")
        model_b = st.text_input("Model B (comparison)", value="qwen2.5:3b")
        st.warning("Could not reach Ollama or no models are installed. Start Ollama and pull a model.")
    temperature = st.slider("Temperature", 0.0, 2.0, 0.7, 0.1,
                            help="Lower values are more focused; higher values are more varied.")
    max_tokens = st.slider("Maximum output tokens", 32, 2048, 512, 32)
    compare = st.toggle("Compare two models", value=True)
    st.caption("Use the same prompt and settings for a fair comparison.")

st.subheader("Prompt studio")
case = st.selectbox("Choose a practical use case", list(USE_CASES.keys()))
preset = USE_CASES[case]
system_prompt = st.text_area("System prompt", value=preset["system"], height=90)
user_prompt = st.text_area("User prompt", value=preset["prompt"], height=220,
                           help="Write the task and provide any input text or context.")

col1, col2 = st.columns(2)
with col1:
    run_button = st.button("▶ Run prompt", type="primary", use_container_width=True)
with col2:
    clear_button = st.button("Clear results", use_container_width=True)

if clear_button:
    st.session_state.pop("results", None)
    st.rerun()

if run_button:
    if not user_prompt.strip():
        st.warning("Enter a user prompt before running.")
    elif not model_a.strip():
        st.warning("Enter a model name.")
    else:
        try:
            with st.spinner("Generating response with your local model..."):
                result_a = run_model(ollama_url, model_a, system_prompt, user_prompt,
                                     temperature, max_tokens)
                results = {"A": (model_a, result_a)}
                if compare and model_b.strip() and model_b != model_a:
                    result_b = run_model(ollama_url, model_b, system_prompt, user_prompt,
                                         temperature, max_tokens)
                    results["B"] = (model_b, result_b)
                st.session_state["results"] = results
        except requests.exceptions.ConnectionError:
            st.error("Cannot connect to Ollama. Make sure Ollama is installed and running, then try again.")
        except requests.exceptions.HTTPError as exc:
            detail = ""
            try:
                detail = exc.response.json().get("error", "")
            except Exception:
                pass
            st.error(f"Ollama returned an error: {detail or exc}")
        except requests.exceptions.Timeout:
            st.error("The model took too long to respond. Try a smaller model or shorter prompt.")
        except requests.RequestException as exc:
            st.error(f"Request failed: {exc}")

if "results" in st.session_state:
    st.divider()
    st.subheader("Model responses")
    results = st.session_state["results"]
    response_cols = st.columns(len(results))
    for col, (label, (model, result)) in zip(response_cols, results.items()):
        with col:
            st.markdown(f"### Model {label}: `{model}`")
            st.markdown(result["text"] or "_The model returned an empty response._")
            m1, m2, m3 = st.columns(3)
            m1.metric("Prompt tokens", result["prompt_tokens"])
            m2.metric("Output tokens", result["completion_tokens"])
            m3.metric("Total tokens", result["total_tokens"])
            st.caption(f"Time: {result['duration']:.2f}s · Finish: {result['finish_reason']}")

    if len(results) == 2:
        a = results["A"][1]["total_tokens"]
        b = results["B"][1]["total_tokens"]
        st.info(f"Token usage comparison: Model A used {a} tokens; Model B used {b} tokens.")

with st.expander("🧠 Understand the controls"):
    st.markdown("""
    - **System prompt:** Sets the assistant's role, behavior, and response rules.
    - **User prompt:** Describes the task and supplies the content to work on.
    - **Temperature:** Controls response variation. Try `0.0` for more consistent output and `1.2` for more varied output.
    - **Maximum output tokens:** Limits the generated response length. A low limit can cut off an answer.
    - **Model comparison:** Runs the same prompts and settings on two local models.
    - **Token counts:** Ollama reports prompt and generated token counts for each response.
    """)

st.caption("Built with Streamlit and Ollama. Models run locally on your computer; no API key is used.")
