# LLM Playground (No API Key)

A Streamlit web application for experimenting with prompts and comparing large language models through Ollama's local HTTP API. No OpenAI API key is required.

## Features

- Prompt Studio with editable system and user prompts
- Five practical use cases:
  1. Text summarizer
  2. Professional email writer
  3. Code explainer
  4. Sentiment analyzer
  5. Interview coach
- Compare two local models side by side
- Adjust temperature and maximum output tokens
- View prompt tokens, output tokens, total tokens, and response time
- Clear results and refresh the installed model list

## Requirements

- Windows, macOS, or Linux
- Python 3.10+
- Ollama installed
- Enough RAM for the model you choose

## Setup on Windows

1. Install Ollama from https://ollama.com/download
2. Open a terminal and download a model:

   ```powershell
   ollama pull llama3.2
   ```

   Optional second model for comparison:

   ```powershell
   ollama pull qwen2.5:3b
   ```

3. Extract this project ZIP and open the extracted folder in VS Code.
4. Open the VS Code terminal in the project folder and run:

   ```powershell
   python -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   streamlit run app.py
   ```

5. Open http://localhost:8501 in your browser.

Ollama normally runs in the background at `http://localhost:11434`. If the model list is empty, ensure Ollama is running and use `ollama list` to check installed models. Then click **Refresh model list** in the app.

## Publish a demo

This version uses a local Ollama server. A public Streamlit deployment cannot access Ollama running on your personal computer unless you configure a separately hosted, reachable Ollama server. For a classroom demo, run it locally and share your screen. For a public hosted demo, deploy the app and configure a secure hosted Ollama endpoint; do not expose an unauthenticated model server to the public internet.

## Notes

- The first model download requires internet access. After download, inference can run locally.
- Model downloads can be large and depend on available disk space.
- Model speed and quality depend on your computer hardware and selected model.
- Temperature and output token settings are sent to Ollama as model options.
- Token counts are reported by the local model runtime and may differ from provider-specific tokenization.
